package com.aws.learning;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AwslearningApplicationTests {

	@Test
	void contextLoads() {
	}

}
